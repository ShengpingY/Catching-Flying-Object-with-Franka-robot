#include <cmath>
#include <iostream>
#include <vector>
#include <string>
#include <franka/exception.h>
#include <franka/robot.h>
#include "examples_common.h"
#include "examples_common.cpp"
#include "geometry_msgs/Point.h"
#include "csvreader.cpp"
#include <ros/ros.h>
#include <Eigen/Dense>
//Includes of MoveIt Packages
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>
#include <moveit_msgs/AttachedCollisionObject.h>
#include <moveit_msgs/CollisionObject.h>
#include <moveit_visual_tools/moveit_visual_tools.h>

geometry_msgs::Pose target_pose;
geometry_msgs::Pose current_pose;
bool msg_received_flag;


void motion_callback(const geometry_msgs::Point &msg){
    msg_received_flag = true;
    ROS_INFO("Destination receieved is %f,%f,%f", msg.x, msg.y, msg.z);
    target_pose.position.x=msg.x;
    target_pose.position.y=msg.y;
    target_pose.position.z=msg.z;
    target_pose.orientation.x=current_pose.orientation.x;
    target_pose.orientation.y=current_pose.orientation.y;
    target_pose.orientation.z=current_pose.orientation.z;

    if(target_pose.position.x<-1.6 || target_pose.position.x>0 || target_pose.position.y< -2.6 || target_pose.position.y>-1.5){
      msg_received_flag = false;
      ROS_INFO("Destination invalid");
    }
    


}

int main(int argc, char** argv) {
  // if (argc != 2) {
  //   std::cerr << "Usage: " << argv[0] << " <robot-hostname>" << std::endl;
  //   return -1;
  // }

    ros::init(argc, argv, "moveit_control");
    ros::NodeHandle node_handle;

    ros::Subscriber sub = node_handle.subscribe("/transformed_coord",1,motion_callback);
    // setups for moveit
    static const std::string PLANNING_GROUP = "panda_arm";
    moveit::planning_interface::MoveGroupInterface move_group_interface(PLANNING_GROUP);
    const moveit::core::JointModelGroup* joint_model_group = move_group_interface.getCurrentState()->getJointModelGroup(PLANNING_GROUP);

    //Move to initial position
    geometry_msgs::PoseStamped current_pose_msg = move_group_interface.getCurrentPose();
    current_pose = current_pose_msg.pose;
    geometry_msgs::Pose init_pose = current_pose;
    init_pose.position.x=0.55;
    init_pose.position.y=-0.05;
    init_pose.position.z=0.8;

    move_group_interface.setStartState(*move_group_interface.getCurrentState());
    move_group_interface.setPoseTarget(init_pose);
    moveit::planning_interface::MoveGroupInterface::Plan my_plan;
    bool success = (move_group_interface.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);

    std::cout << "WARNING: The Robot will be moved to initial pose "
                 "Please make sure to have the user stop button at hand!" << std::endl
              << "Press Enter to continue..." << std::endl;
    std::cin.ignore();

    move_group_interface.execute(my_plan);
    ros::spinOnce();

    std::cout << "Initial Pose reached! "
                 "WARNING: This will move the robot! "
                 "Please make sure to have the user stop button at hand!" << std::endl
              << "Press Enter to continue..." << std::endl;
    std::cin.ignore();
    //ros::AsyncSpinner spinner(1);
    //spinner.start();

    while(ros::ok()) {
          
   
        ros::spinOnce();

            if(msg_received_flag){
                move_group_interface.setPoseTarget(target_pose);
                moveit::planning_interface::MoveGroupInterface::Plan my_plan;
                move_group_interface.plan(my_plan);
                move_group_interface.execute(my_plan);
                msg_received_flag = false;
            } 
  }
}



/*
    //This Section presents codes for a simple movement

    //get the current position
    
    geometry_msgs::PoseStamped current_pose_msg = move_group_interface.getCurrentPose();
    geometry_msgs::Pose start_pose = current_pose_msg.pose;
    geometry_msgs::Pose start_pose2 = start_pose;
    start_pose2.position.x=0.55;
    start_pose2.position.y=-0.05;
    start_pose2.position.z=0.8;
    //Make a plan
    moveit::core::RobotState start_state(*move_group_interface.getCurrentState());
    //start_state.setFromIK(joint_model_group,start_pose2);
    move_group_interface.setStartState(start_state);
    //move_group_interface.setStartState(*move_group_interface.getCurrentState());
    move_group_interface.setPoseTarget(start_pose2);
    moveit::planning_interface::MoveGroupInterface::Plan my_plan;
    bool success = (move_group_interface.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
    std::cout << "Planning " << success  << std::endl;
    std::cin.ignore();

    //Execute plan
    move_group_interface.execute(my_plan);
    //move_group_interface.move();

    //Get the Position after execution
    current_pose_msg = move_group_interface.getCurrentPose();
    start_pose = current_pose_msg.pose;

    std::cout << "x = %d" << start_pose.position.x << std::endl
              << "y = %d" << start_pose.position.y << std::endl
              << "z = %d" << start_pose.position.z << std::endl
              << "w = %d" << start_pose.orientation.w << std::endl;
    std::cin.ignore();
    */
   
    //This Section presents codes for a cartesian movement   
    //Plan a Cartesian path directly by specifying a list of waypoints for the end-effector to go through.
    
    //get the current position
    //geometry_msgs::PoseStamped current_pose_msg = move_group_interface.getCurrentPose();
    //geometry_msgs::Pose start_pose = current_pose_msg.pose;
    
    //set the waypoints
    //geometry_msgs::Pose target_pose1=start_pose;
    //target_pose1.position.z=target_pose1.position.z-0.3;
    //target_pose1.position.x=target_pose1.position.x+0.3;
    //target_pose1.position.y=target_pose1.position.y+0.2;

    /*geometry_msgs::PoseStamped current_pose_msg = move_group_interface.getCurrentPose();
    geometry_msgs::Pose start_pose2 = current_pose_msg.pose;

    std::cout << "x = %d" << start_pose2.position.x << std::endl
              << "y = %d" << start_pose2.position.y << std::endl
              << "z = %d" << start_pose2.position.z << std::endl
              << "w = %d" << start_pose2.orientation.w << std::endl;
    std::cin.ignore(); 

    std::vector<geometry_msgs::Pose> waypoints;
    waypoints.push_back(start_pose2);
    
    
    geometry_msgs::Pose target_pose3=start_pose2;
    target_pose3.position.z-=0.2;
    waypoints.push_back(target_pose3);

    target_pose3.position.y-=0.2;
    waypoints.push_back(target_pose3);

    target_pose3.position.z+=0.2;
    target_pose3.position.y+=0.2;
    target_pose3.position.x-=0.2;
    waypoints.push_back(target_pose3);

    //Make a trajectory and plan based on the waypoints
    move_group_interface.setMaxVelocityScalingFactor(0.1); //This maybe wont work, but lets see
    moveit_msgs::RobotTrajectory trajectory;
    const double jump_threshold = 1;
    const double eef_step = 0.01;
    double fraction = move_group_interface.computeCartesianPath(waypoints, eef_step, jump_threshold, trajectory);
    std::cout << fraction <<std::endl;
    std::cin.ignore();
    moveit::planning_interface::MoveGroupInterface::Plan my_plan;
    my_plan.trajectory_= trajectory;

    //Excute the plan
    move_group_interface.execute(my_plan);
    //move_group_interface.move();
    */

  //   } catch (const franka::Exception& e) {
  //   std::cout << e.what() << std::endl;
  //   return -1;
  // }
  // return 0;