#include <cmath>
#include <iostream>
#include <vector>
#include <string>
#include <franka/exception.h>
#include <franka/robot.h>
#include "examples_common.h"
#include "examples_common.cpp"
#include "geometry_msgs/Point.h"
#include "csvreader.cpp"
#include <ros/ros.h>
#include <Eigen/Dense>
//Includes of MoveIt Packages
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>
#include <moveit_msgs/AttachedCollisionObject.h>
#include <moveit_msgs/CollisionObject.h>
#include <moveit_visual_tools/moveit_visual_tools.h>

int main(int argc, char** argv) {
  if (argc != 2) {
    std::cerr << "Usage: " << argv[0] << " <robot-hostname>" << std::endl;
    return -1;
  }
  try {
    franka::Robot robot(argv[1]);
    setDefaultBehavior(robot);
    // First move the robot to a suitable joint configuration
    std::array<double, 7> q_goal = {{0, -M_PI_4, 0, -3 * M_PI_4, 0, M_PI_2, M_PI_4}};
    MotionGenerator motion_generator(0.2, q_goal);
    std::cout << "WARNING: This example will move the robot! "
              << "Please make sure to have the user stop button at hand!" << std::endl
              << "Press Enter to continue..." << std::endl;
    std::cin.ignore();
    robot.control(motion_generator);
    std::cout << "Finished moving to initial joint configuration." << std::endl;
    std::cout << "WARNING: This programm will move the robot! "
              << "Please make sure to have the user stop button at hand!" << std::endl
              << "Press Enter to continue..." << std::endl;
    std::cin.ignore();
    // Set additional parameters always before the control loop, NEVER in the control loop!
    // Set collision behavior.
    robot.setCollisionBehavior(
        {{20.0, 20.0, 18.0, 18.0, 16.0, 14.0, 12.0}}, {{20.0, 20.0, 18.0, 18.0, 16.0, 14.0, 12.0}},
        {{20.0, 20.0, 18.0, 18.0, 16.0, 14.0, 12.0}}, {{20.0, 20.0, 18.0, 18.0, 16.0, 14.0, 12.0}},
        {{20.0, 20.0, 20.0, 25.0, 25.0, 25.0}}, {{20.0, 20.0, 20.0, 25.0, 25.0, 25.0}},
        {{20.0, 20.0, 20.0, 25.0, 25.0, 25.0}}, {{20.0, 20.0, 20.0, 25.0, 25.0, 25.0}});

    ros::init(argc, argv, "cartesian_movement");
    ros::NodeHandle node_handle;

    // ROS spinning must be running for the MoveGroupInterface to get information
    // about the robot's state. One way to do this is to start an AsyncSpinner
    // beforehand.
    ros::AsyncSpinner spinner(1);
    spinner.start();

    // setups
    static const std::string PLANNING_GROUP = "panda_arm";
    moveit::planning_interface::MoveGroupInterface move_group_interface(PLANNING_GROUP);
    const moveit::core::JointModelGroup* joint_model_group = move_group_interface.getCurrentState()->getJointModelGroup(PLANNING_GROUP);

    // read current position of the robot

    /* moveit::core::RobotStatePtr current_state = move_group_interface.getCurrentState();

    // Get the end effector link name
    const std::string& end_effector_link = move_group_interface.getEndEffectorLink();
    std::cout << "End Effector links: %s" << end_effector_link  << std::endl;


    // Compute end effector position
    const Eigen::Isometry3d& end_effector_pose = current_state->getGlobalLinkTransform(end_effector_link);

    // Extract position
    Eigen::Vector3d position = end_effector_pose.translation();

    // Assign start posetion
    geometry_msgs::Pose start_pose;
    start_pose.orientation.w = 1.0;
    start_pose.position.x = position.x();  // Assign x value
    start_pose.position.y = position.y();  // Assign y value
    start_pose.position.z = position.z();  // Assign z value
    std::cout << "End Effector Position (x, y, z): " << position.transpose() << std::endl;
    std::cin.ignore();

    // Assign target position
    geometry_msgs::Pose target_pose;
    target_pose.orientation.w = 1.0;  
    target_pose.position.x = position.x()-0.2;  // Assign x value
    target_pose.position.y = position.y();  // Assign y value
    target_pose.position.z = position.z();  // Assign z value
    */

    //get the current position
    geometry_msgs::PoseStamped current_pose_msg = move_group_interface.getCurrentPose();
    geometry_msgs::Pose start_pose = current_pose_msg.pose;

    std::cout << "x = %d" << start_pose.position.x << std::endl
              << "y = %d" << start_pose.position.y << std::endl
              << "z = %d" << start_pose.position.z << std::endl;
    std::cin.ignore();

    //set the target position
    geometry_msgs::Pose target_pose;
    target_pose.orientation.w = start_pose.orientation.w;  
    target_pose.position.x = start_pose.position.x-0.2;  // Assign x value
    target_pose.position.y = start_pose.position.y;  // Assign y value
    target_pose.position.z = start_pose.position.z;  // Assign z value

    //Plan a Cartesian path directly by specifying a list of waypoints for the end-effector to go through.
    std::vector<geometry_msgs::Pose> waypoints;
    waypoints.push_back(start_pose);
    waypoints.push_back(target_pose);

    //Make a trajectory based on the waypoints
    move_group_interface.setMaxVelocityScalingFactor(0.1); //This maybe wont work, but lets see
    moveit_msgs::RobotTrajectory trajectory;
    const double jump_threshold = 0.0;
    const double eef_step = 0.01;
    double fraction = move_group_interface.computeCartesianPath(waypoints, eef_step, jump_threshold, trajectory);

    //Excute the trajectory
    move_group_interface.execute(trajectory);
    /*
    //Alternatively:
    move_group.setPoseTarget(target_pose);
    moveit::planning_interface::MoveGroupInterface::Plan my_plan;
    bool success = (move_group_interface.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
    std::cout << "Planning %s", success ? "SUCCEED" : "FAILED" << std::endl;
    std::cin.ignore();

    //Execute plan
    move_group_interface.execute(my_plan);
    move_group_interface.move();
    /*

    */


    } catch (const franka::Exception& e) {
    std::cout << e.what() << std::endl;
    return -1;
  }
  return 0;
}