This project is based on optitrack, ROS-Noetic, ROS-Humble and Franka Panda Robot. Aim of it is trying to track a thrown ball with optitrack camera system and moving robot arm to predicted falling position.

Overall there are three parts of the this project:
  1. Parabolic prediction of the ball.
  2. Robot arm trajectory plan.
  3. Motion controller based on trajectory.

All those three parts are under different branch.
